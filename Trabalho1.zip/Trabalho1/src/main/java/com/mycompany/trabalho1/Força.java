/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalho1;

/**
 *
 * @author riche
 */
public class Força {
    //Atributos publicos
    protected int força;
    protected int vida;
    protected String genero;
    protected String nome;
    
    //Metodos publicos
    public void atacar (int f){
        força = f;
    }
}
