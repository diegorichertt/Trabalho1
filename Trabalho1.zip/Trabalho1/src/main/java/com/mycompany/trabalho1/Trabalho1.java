/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabalho1;

/**
 *
 * @author riche
 */
public class Trabalho1 {
    public static void main(String[] args) {
        // Criando instâncias de Jedi e Sith
        Padawan padawan = new Padawan();
        Cavaleiro cavaleiro = new Cavaleiro();
        MestreJedi mestreJedi = new MestreJedi();
        Aprendiz aprendizSith = new Aprendiz();
        Lord lordSith = new Lord();
        MestreSith mestreSith = new MestreSith();

        // Configurando atributos e ações
        padawan.nome = "Padawan Anakin";
        padawan.setForça(20);
        padawan.setGenero("Masculino");
        System.out.println(padawan.nome + " - Gênero: " + padawan.genero + ", Força: " + padawan.força);

        cavaleiro.nome = "Cavaleiro Obi-Wan";
        cavaleiro.setForça(70);
        cavaleiro.setGenero("Masculino");
        System.out.println(cavaleiro.nome + " - Gênero: " + cavaleiro.genero + ", Força: " + cavaleiro.força);

        mestreJedi.nome = "Mestre Yoda";
        mestreJedi.setForça(100);
        mestreJedi.setGenero("Masculino");
        System.out.println(mestreJedi.nome + " - Gênero: " + mestreJedi.genero + ", Força: " + mestreJedi.força);

        aprendizSith.nome = "Aprendiz Darth Maul";
        aprendizSith.setForça(40);
        aprendizSith.setGenero("Masculino");
        System.out.println(aprendizSith.nome + " - Gênero: " + aprendizSith.genero + ", Força: " + aprendizSith.força);

        lordSith.nome = "Lord Darth Vader";
        lordSith.setForça(80);
        lordSith.setGenero("Masculino");
        System.out.println(lordSith.nome + " - Gênero: " + lordSith.genero + ", Força: " + lordSith.força);

        mestreSith.nome = "Mestre Darth Sidious";
        mestreSith.setForça(120);
        mestreSith.setGenero("Masculino");
        System.out.println(mestreSith.nome + " - Gênero: " + mestreSith.genero + ", Força: " + mestreSith.força);

        // Exemplos de interações
        System.out.println("\nInterações de combate e poderes:");
        padawan.atacar(10);
        System.out.println(padawan.nome + " ataca com força " + padawan.força);

        lordSith.atacar(50);
        System.out.println(lordSith.nome + " ataca com força " + lordSith.força);

        // Mestres usando raios (precisaria implementar o comportamento do raio)
        try {
            mestreJedi.usarRaio();
        } catch (UnsupportedOperationException e) {
            System.out.println(mestreJedi.nome + " não pode usar raios.");
        }

        try {
            mestreSith.usarRaio();
        } catch (UnsupportedOperationException e) {
            System.out.println(mestreSith.nome + " usa raios de cor desconhecida.");
        }
    }
}

